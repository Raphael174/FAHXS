""" 
@ author : Raphaël Aubry
"""

""" 
Script to estimate Kerosene combustion chemistry using cantera
"""
#%%
import cantera as ctr 
from pathlib import Path
import numpy as np 
import matplotlib.pyplot as plt

ctr.suppress_thermo_warnings()

#%%

base_path = Path(__file__).parent

JETA_chem_path = base_path / "A2highT.yaml"

#%%

class combustion_gas_solve :

    def __init__ (self, 
                  fuel, oxidizer,
                  OF,
                  p0,
                  T_g_init,
                  T_inj_LOX):
        
        self.fuel = fuel 
        self.oxidizer
        self.OF = OF 
        self.p0 = p0 
        self.T_g_init = T_g_init 
        self.self.T_inj_LOX = T_inj_LOX 

        self.phase = ctr.Solution(JETA_chem_path)

        # enthalpy of vaporization
        self.Hv_JetA = 0.36e6 #J/kg  https://web.stanford.edu/group/haiwanglab/HyChem/approach/Report_Jet_Fuel_Thermochemical_Properties_v6.pdf

    def solve (self) :

        O = self.OF/(1 + self.OF)
        F = 1 - O

        """ENERGY LOSS LOX-->GOX"""

        # LOX TO GOX
        O2 = ctr.Oxygen() # import oxygen 
        O2.TP = self.T_inj_LOX, self.p0 # set O2 to injection thermo
        self.h_ox_inj = O2.enthalpy_mass # fetch O2 onjection enthalpy
        O2.TP = self.T_g_init, self.p0 # set O2 to reaction state, assumed at T_pyro
        self.h_ox_pyro = O2.enthalpy_mass
        self.dH_ox = self.h_ox_pyro-self.h_ox_inj

        self.dH_tot = O*self.dH_ox + F*self.Hv_JetA


        """CHEMICAL EQUILIBRIUM CALCULATION"""


        self.phase.TPY = self.T_g_init, self.p0,  "O2" + ':' + str(self.OF) + ',' +  self.fuel + ': 1' 

        self.phase.equilibrate('HP') # finding chem equilibrium

        self.phase.HP = self.phase.enthalpy_mass-self.dH_tot, self.p0 # remove energy loss
        self.phase.equilibrate('HP') # re-equilibriate mixture

    def remove_energy (self, dh, updated_phase): 

        # enthalpy to remove
        self.dh = dh 
        self.updated_phase = updated_phase

        # equilibriate with removed energy
        self.updated_phase.HP = self.updated_phase.enthalpy_mass-self.dh, self.p0 # remove energy loss
        self.updated_phase.equilibrate('HP') # re-equilibriate mixture
        